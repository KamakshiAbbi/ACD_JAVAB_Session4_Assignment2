//Session4_Assignment2 : 8.5.2016
//Author: Kamakshi Abbi
import java.util.Scanner;
public class Session4Assign2 {

	//Sort the array in ascending 
	public static void sortAsc( int arr[]){
		for (int i = 0; i < arr.length; i++) {
			for (int j = i+1; j < arr.length; j++) {
				if(arr[i]>arr[j]){
					int temp = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;
				}
			}
		}
		System.out.println("Printing array in Ascending Order");
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}
		
	}
	//To calculate position
	public static int calculatePos(int arr[], int num){
		int pos=0;
		//first position
		if( num < arr[0]){
			pos = 0;
		}
		//last position
		else if(num > arr[arr.length-1]){
			pos = arr.length;
		}
		//in middle
		else{
			for (int i = 0; i < arr.length-1; i++) {
				if(num >= arr[i] && num < arr[i+1]){
				pos = i+1;
				}	
			}
		}
		return pos;
	}
	//Inserting number to array
	public static void insert( int arr[], int num){
		//Calculating position 
		int pos = calculatePos(arr,num);
		int newArr[] = new int [arr.length + 1];
		newArr[pos] = num;
		//Copying the second half
		for (int i = pos + 1; i <= arr.length; i++) {
				newArr[i] = arr[i-1];
		}
		//Copying first half
		if(pos!=0){
			for (int i = 0; i < pos; i++) {
				newArr[i] = arr[i];
			}
		}
		System.out.println("New Array after inserting: " + num);
		for (int i = 0; i < newArr.length; i++) {
			System.out.println(newArr[i]+" ");
		}
		
	}

	public static void main(String[] args) {
		int arr[] = new int[5];
		System.out.println("Enter 5 number of the array");
		Scanner input = new Scanner(System.in);
		for (int i = 0; i < arr.length; i++) {
			arr[i] =input.nextInt();
		}
		sortAsc(arr);
		System.out.println("Enter the number to be inserted");
		int num = input.nextInt();
		insert(arr,num);
		input.close();
	}
}
